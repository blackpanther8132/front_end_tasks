import { combineReducers } from 'redux';
// import MainApp from '../app/Modules/MainApp/MainApp';



export default combineReducers({
  // [Swixer.constants.NAME]: Swixer.reducer,
});
