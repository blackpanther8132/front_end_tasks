import React, {Component} from 'react'
import {render} from 'react-dom'
import {Launcher} from 'react-chat-window'
 
class Demo extends Component {
 
  constructor() {
    super();
    this.state = {
      
    };
  }
 
  
 
  render() {
    return ()
  }
}
export default Demo;